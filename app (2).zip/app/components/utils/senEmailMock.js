export function sendEmailMock(email) {
  console.log(`📩 Correo enviado a ${email}`);
  console.log('Asunto: Activación de cuenta Bosque Vivo HN');
  console.log('Mensaje: Su registro ha sido validado exitosamente. Credenciales temporales generadas.');
}
